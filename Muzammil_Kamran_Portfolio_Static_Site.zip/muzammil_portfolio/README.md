# Muzammil Kamran Portfolio — free static deployment

This is a single static page: no framework, database, paid theme, build step, or monthly hosting bill is required.

## Best simple free option: GitHub Pages
1. Create a public GitHub repository, e.g. `muzammil-portfolio`.
2. Upload `index.html` and the `assets` folder to the repository root.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**.
5. Select `main` and `/ (root)`.
6. GitHub provides a free `github.io` URL.

You can later attach a custom domain.

## Stronger proof to add next
Add sanitized screenshots or short demo videos for:
- Crossway AI website assistant / WordPress chatbot
- n8n SEO/content workflow
- n8n reporting workflow + Looker Studio dashboard
- GA4/GTM / conversion-tracking architecture or landing-page before/after

Never expose client secrets, API keys, customer PII, ad-account IDs, or private CRM data.
